package com.example.primerparcial

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

private val TAG = "MainActivity"

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Crear las variables necesarias
        val Input1: EditText = findViewById<EditText>(R.id.input1)
        val Input2: EditText = findViewById<EditText>(R.id.input2)
        val Input3: EditText = findViewById<EditText>(R.id.input3)
        val BotonAgregar: Button = findViewById(R.id.botonAgregar)
        val BotonLimpiar: Button = findViewById(R.id.botonLimpiar)
        val result = findViewById<TextView>(R.id.result)

        BotonAgregar?.setOnClickListener(object :View.OnClickListener {
            override fun onClick(p0: View?) {
                Log.d(TAG, "onClick")
                //result?.text="${Input1.text} + ${Input2.text} = ${Input3.text}"

                if(Input1.text.isBlank() or Input2.text.isBlank() or Input3.text.isBlank()){

                }else{
                    result?.append(Input1.text)
                    result?.append("+")
                    result?.append(Input2.text)
                    result?.append("=")
                    result?.append(Input3.text)
                    result?.append("\n")
                    Input1.setText("")
                    Input2.setText("")
                    Input3.setText("")
                    Input1.text.clear()
                    Input2.text.clear()
                    Input3.text.clear()
                }

            }
        })

        BotonLimpiar?.setOnClickListener(object :View.OnClickListener {
            override fun onClick(p0: View?) {
                Log.d(TAG, "onClick Clean")
                Input1.text.clear()
                Input2.text.clear()
                Input3.text.clear()
                result?.setText("")
            }
        })
    }
}